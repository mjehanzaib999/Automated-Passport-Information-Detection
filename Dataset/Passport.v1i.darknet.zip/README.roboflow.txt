
Passport - v1 2021-06-12 12:05pm
==============================

This dataset was exported via roboflow.ai on June 12, 2021 at 7:07 AM GMT

It includes 58 images.
I-labeled-all-the-objs-in-images are annotated in YOLO v3 Darknet format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

No image augmentation techniques were applied.


